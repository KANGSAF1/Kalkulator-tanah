
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from shapely.geometry import Polygon

st.set_page_config(page_title="Pembagian Tanah Sama Luas", layout="centered")
st.title("📏 Pembagian Tanah Sama Luas")

# ==== INPUT ====
st.sidebar.header("Input Data Tanah")
AB = st.sidebar.number_input("Panjang AB (m)", min_value=1.0, value=71.0, step=0.1)
BC = st.sidebar.number_input("Panjang BC (m)", min_value=1.0, value=27.5, step=0.1)
CD = st.sidebar.number_input("Panjang CD (m)", min_value=1.0, value=59.0, step=0.1)
DA = st.sidebar.number_input("Panjang DA (m)", min_value=1.0, value=40.0, step=0.1)
BD = st.sidebar.number_input("Diagonal BD (m)", min_value=1.0, value=72.5, step=0.1)
AC = st.sidebar.number_input("Diagonal AC (m) [Opsional]", min_value=0.0, value=73.0, step=0.1)

jumlah_bidang = st.sidebar.number_input("Jumlah Bidang", min_value=1, value=8, step=1)
arah = st.sidebar.selectbox("Arah Pembagian", ["AB → DC", "AD → BC"])

# ==== KONSTRUKSI KOORDINAT ====
A = np.array([0.0, 0.0])
B = np.array([AB, 0.0])
D = np.array([0.0, DA])
C = np.array([CD, DA])
poly = Polygon([A, B, C, D])
total_area = poly.area

# ==== PEMBAGIAN ====
field_polys = []
t_values = np.linspace(0, 1, jumlah_bidang+1)
for i in range(jumlah_bidang):
    p_top_left = A + (B - A) * t_values[i]
    p_top_right = A + (B - A) * t_values[i+1]
    p_bottom_left = D + (C - D) * t_values[i]
    p_bottom_right = D + (C - D) * t_values[i+1]
    field = Polygon([p_top_left, p_top_right, p_bottom_right, p_bottom_left])
    field_polys.append(field)

# ==== TABEL DATA ====
data = []
for idx, f in enumerate(field_polys, start=1):
    coords = list(f.exterior.coords)
    top_len = np.linalg.norm(np.array(coords[0]) - np.array(coords[1]))
    bottom_len = np.linalg.norm(np.array(coords[2]) - np.array(coords[3]))
    avg_width = f.area / ((top_len + bottom_len) / 2)
    data.append({
        "Bidang": idx,
        "Sisi Atas (m)": round(top_len, 2),
        "Sisi Bawah (m)": round(bottom_len, 2),
        "Lebar Rata-rata (m)": round(avg_width, 2),
        "Luas (m²)": round(f.area, 2)
    })

df = pd.DataFrame(data)
st.subheader("📋 Tabel Data Bidang")
st.dataframe(df)

# ==== GAMBAR DENAH ====
fig, ax = plt.subplots(figsize=(8,6))
x, y = poly.exterior.xy
ax.plot(x, y, 'k-')
ax.fill(x, y, alpha=0.1)
for field in field_polys:
    fx, fy = field.exterior.xy
    ax.plot(fx, fy, 'gray', alpha=0.7)
for i, f in enumerate(field_polys, start=1):
    coords = list(f.exterior.coords)
    top_len = np.linalg.norm(np.array(coords[0]) - np.array(coords[1]))
    bottom_len = np.linalg.norm(np.array(coords[2]) - np.array(coords[3]))
    avg_width = f.area / ((top_len + bottom_len) / 2)
    centroid = f.centroid
    ax.text((coords[0][0]+coords[1][0])/2, (coords[0][1]+coords[1][1])/2, f"{top_len:.2f} m", color='blue', fontsize=8, ha='center', va='bottom')
    ax.text((coords[2][0]+coords[3][0])/2, (coords[2][1]+coords[3][1])/2, f"{bottom_len:.2f} m", color='green', fontsize=8, ha='center', va='top')
    ax.text((coords[1][0]+coords[2][0])/2, (coords[1][1]+coords[2][1])/2, f"{avg_width:.2f} m", color='purple', fontsize=8, ha='left', va='center')
    ax.text(centroid.x, centroid.y, f"{f.area:.2f} m²", fontsize=8, ha='center', va='center', bbox=dict(facecolor='white', alpha=0.5, edgecolor='none'))
for name, pt in zip(["A","B","C","D"], [A,B,C,D]):
    ax.text(pt[0], pt[1], name, fontsize=10, fontweight='bold')
ax.set_aspect('equal')
ax.set_title("Denah Pembagian Tanah Sama Luas\nAtas (biru), Bawah (hijau), Lebar (ungu), Luas (hitam)")
st.pyplot(fig)

csv = df.to_csv(index=False).encode()
st.download_button("📥 Download Tabel CSV", csv, "pembagian_tanah.csv", "text/csv")
