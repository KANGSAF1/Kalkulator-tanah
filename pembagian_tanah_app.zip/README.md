# Pembagian Tanah Sama Luas
Aplikasi Streamlit untuk membagi tanah menjadi beberapa bidang dengan luas sama.
